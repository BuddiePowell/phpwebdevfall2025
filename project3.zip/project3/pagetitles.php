<?php
define('HOME_PAGE', 'ActivityLog - Home');
define('VIEW_PROFILE', 'ActivityLog - View Profile');
define('LOG_EXERCISE', 'ActivityLog - Log Exercise');
define('EDIT_PROFILE', 'ActivityLog - Edit Profile');
define('DELETE_LOG_ENTRY', 'ActivityLog - Delete Log Entry');
define('SIGN_UP', 'ActivityLog - SignUp');
define('LOGIN', 'Activitylog - Login');
define('LOGOUT', 'Activitylog - Logout');
?>