<?php
    // Database connection constants for the project  database
    define('DB_HOST', 'localhost');
    define('DB_USER', 'student');
    define('DB_PASSWORD', 'student');
    define('DB_NAME', 'gamecollection');
    ?>