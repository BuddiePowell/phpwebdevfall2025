<?php
// pagetitles.php
define('HOME', 'Video Game Collection - Home');
define('LOGIN', 'Video Game Collection - Login');
define('LOGOUT', 'Video Game Collection - Logout');
define('ADD_VIDEO_GAME', 'Video Game Collection - Add a Video Game');
define('EDIT_PROFILE', 'Video Game Collection - Edit Profile');
define('VIEW_PROFILE', 'Video Game Collection - View Profile');
define('CREATE_USER', 'Video Game Collection - Create User');
?>