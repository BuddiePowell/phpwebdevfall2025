<?php
    // Database connection constants for the project 2 database
    define('DB_HOST', 'localhost');
    define('DB_USER', 'blogapp');
    define('DB_PASSWORD', 'iluvposting');
    define('DB_NAME', 'Post');